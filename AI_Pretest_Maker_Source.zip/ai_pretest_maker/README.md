# AI Pretest Maker — Android starter project

Prototype pribadi Android (Kotlin + Jetpack Compose) dengan backend Node.js yang memanggil Gemini. Ini adalah source project awal, bukan APK yang sudah ter-build.

## Isi paket
- `app/`: aplikasi Android, pemilih PDF, koneksi HTTPS ke backend, ekspor hasil ke HTML.
- `backend/`: API Node.js; API key Gemini hanya disimpan di server.
- `prototype/index.html`: mockup visual sederhana.

## Menyiapkan backend Gemini
1. Buat API key di Google AI Studio.
2. Deploy folder `backend` ke layanan Node.js yang mendukung HTTPS.
3. Atur environment variable `GEMINI_API_KEY` di server (jangan masukkan ke APK atau unggah ke Git).
4. Opsional: atur `GEMINI_MODEL=gemini-2.5-flash`.
5. Jalankan `npm install` lalu `npm start`.
6. Pastikan `https://alamat-server/health` mengembalikan `{"ok":true,...}`.

API menerima `POST /api/quiz` dengan multipart field `file` berisi PDF. Batas awal 18 MB. Server mengirim PDF ke Gemini sebagai inline PDF dan meminta JSON 10 soal.

## Build APK di Android Studio
1. Ekstrak ZIP ini.
2. Buka folder `ai_pretest_maker` melalui Android Studio versi yang mendukung Android Gradle Plugin 8.7.3.
3. Tunggu Gradle Sync dan pastikan JDK 17 terpasang.
4. Jalankan di emulator/HP untuk tes.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).

## Konfigurasi aplikasi
Di aplikasi, isi alamat backend dengan URL HTTPS milik server, contoh `https://quiz-api.domainkamu.com` (tanpa `/api/quiz`). Jangan gunakan `localhost` dari HP untuk server di komputer.

## Catatan penting
- Source ini belum diuji build di Android Studio pada lingkungan ini; belum ada APK terkompilasi.
- API key Gemini tidak boleh ditaruh di aplikasi Android. Backend perlu HTTPS, pembatasan ukuran file, autentikasi atau pembatasan akses, rate limit, dan kebijakan privasi sebelum dipakai rutin.
- Versi awal menampilkan data kuis JSON dan ekspor HTML sederhana; peningkatan berikutnya adalah game UI native penuh, penyimpanan riwayat lokal, validasi lebih ketat, serta penanganan PDF scan/OCR.
- PDF yang besar atau berisi banyak halaman/gambar dapat memerlukan Files API atau pemrosesan bertahap.
