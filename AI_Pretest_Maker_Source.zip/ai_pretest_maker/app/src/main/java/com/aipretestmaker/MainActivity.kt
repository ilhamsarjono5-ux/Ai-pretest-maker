package com.aipretestmaker

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

private val Navy = Color(0xFF101426)
private val Panel = Color(0xFF1B2340)
private val Purple = Color(0xFF8B7CFF)
private val Mint = Color(0xFF66E0C2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Navy, surface = Panel)) { MakerScreen() } }
    }
}

@Composable
fun MakerScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pdfUri by remember { mutableStateOf<Uri?>(null) }
    var pdfName by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Upload modul praktikum untuk mulai") }
    var busy by remember { mutableStateOf(false) }
    var quizText by remember { mutableStateOf("") }
    var backendUrl by remember { mutableStateOf("https://YOUR-BACKEND-DOMAIN") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            pdfUri = uri
            pdfName = uri.lastPathSegment?.substringAfterLast('/') ?: "Modul PDF"
            status = "PDF siap dianalisis"
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        }
    }
    val saveHtml = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/html")) { uri ->
        if (uri != null && quizText.isNotBlank()) {
            context.contentResolver.openOutputStream(uri)?.use { it.write(buildHtml(quizText).toByteArray()) }
            status = "HTML berhasil disimpan"
        }
    }

    Column(Modifier.fillMaxSize().background(Navy).verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(color = Purple.copy(alpha = .18f), shape = RoundedCornerShape(16.dp)) { Icon(Icons.Default.AutoAwesome, null, tint = Mint, modifier = Modifier.padding(12.dp).size(28.dp)) }
            Spacer(Modifier.width(12.dp))
            Column { Text("AI PRETEST MAKER", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 21.sp); Text("PDF masuk. Kuis langsung jadi.", color = Color.LightGray, fontSize = 12.sp) }
        }
        Surface(color = Panel, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Buat kuis baru", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Pilih modul praktikum dalam format PDF. AI akan mengambil konsep penting dan menyusun soal menantang.", color = Color.LightGray)
                OutlinedButton(onClick = { picker.launch(arrayOf("application/pdf")) }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Description, null); Spacer(Modifier.width(8.dp)); Text(if (pdfName.isBlank()) "Pilih file PDF" else pdfName)
                }
                OutlinedTextField(value = backendUrl, onValueChange = { backendUrl = it }, label = { Text("Alamat backend AI") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Button(onClick = {
                    val uri = pdfUri
                    if (uri == null) { status = "Pilih PDF terlebih dahulu"; return@Button }
                    if (!backendUrl.startsWith("https://")) { status = "Isi alamat backend HTTPS yang sudah dipasang"; return@Button }
                    busy = true; status = "AI sedang membaca PDF dan menyusun soal..."
                    scope.launch {
                        try {
                            val bytes = withContext(Dispatchers.IO) { context.contentResolver.openInputStream(uri)!!.use { it.readBytes() } }
                            val body = withContext(Dispatchers.IO) {
                                val fileBody = bytes.toRequestBody("application/pdf".toMediaType())
                                val multipart = MultipartBody.Builder().setType(MultipartBody.FORM).addFormDataPart("file", pdfName.ifBlank { "modul.pdf" }, fileBody).build()
                                val request = Request.Builder().url(backendUrl.trimEnd('/') + "/api/quiz").post(multipart).build()
                                OkHttpClient().newCall(request).execute().use { response ->
                                    val text = response.body?.string().orEmpty()
                                    if (!response.isSuccessful) error("Server ${response.code}: $text")
                                    text
                                }
                            }
                            val root = JSONObject(body)
                            quizText = root.getJSONObject("quiz").toString(2)
                            status = "Kuis berhasil dibuat! Siap dimainkan dan diekspor."
                        } catch (e: Exception) { status = "Gagal: ${e.message ?: "Periksa koneksi dan backend"}" }
                        finally { busy = false }
                    }
                }, enabled = !busy, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Purple)) {
                    if (busy) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp) else Icon(Icons.Default.AutoAwesome, null)
                    Spacer(Modifier.width(8.dp)); Text(if (busy) "Memproses PDF..." else "Buat kuis dengan AI")
                }
                Text(status, color = Mint, fontSize = 13.sp)
            }
        }
        Surface(color = Panel, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Quiz, null, tint = Mint); Spacer(Modifier.width(8.dp)); Text("Hasil kuis", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp) }
                if (quizText.isBlank()) Text("Belum ada kuis. Setelah AI selesai, hasilnya akan muncul di sini.", color = Color.LightGray)
                else {
                    Text("Kuis berhasil dibuat. File HTML dapat dibuka di browser atau dibagikan.", color = Color.LightGray)
                    Button(onClick = { saveHtml.launch("pretest-ai.html") }, modifier = Modifier.fillMaxWidth()) { Text("Ekspor kuis ke HTML") }
                    Text(quizText.take(900) + if (quizText.length > 900) "…" else "", color = Color(0xFFD7D9E8), fontSize = 11.sp)
                }
            }
        }
        Text("Versi prototipe 0.1.0 · Gemini AI · penggunaan pribadi", color = Color.Gray, fontSize = 11.sp)
    }
}

private fun buildHtml(rawJson: String): String {
    val safe = JSONObject.quote(rawJson)
    return """<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>AI Pretest Maker</title><style>body{font-family:system-ui;background:#101426;color:#fff;margin:0;padding:20px}.card{max-width:720px;margin:auto;background:#1b2340;padding:22px;border-radius:20px}button{background:#8b7cff;color:white;border:0;padding:13px 18px;border-radius:12px;margin:6px;cursor:pointer} .opt{display:block;width:100%;text-align:left;background:#30395c}small{color:#b8bdd2}</style></head><body><main class="card"><h1>✨ AI PRETEST MAKER</h1><p id="meta">Kuis dari materi PDF</p><div id="app">Memuat kuis...</div></main><script>const raw=JSON.parse($safe);let qz=raw.questions||[];let i=0,score=0,answered=false;function render(){if(i>=qz.length){app.innerHTML='<h2>🎉 Kuis selesai!</h2><h1>'+score+' / '+qz.length+'</h1><p>Nilai: '+Math.round(score/qz.length*100)+'</p><button onclick="location.reload()">Main lagi</button>';return}let q=qz[i];answered=false;app.innerHTML='<small>SOAL '+(i+1)+' / '+qz.length+'</small><h2>'+q.question+'</h2>'+q.options.map((o,n)=>'<button class="opt" onclick="answer('+n+')">'+o.label+'</button>').join('')+'<p id="feedback"></p>'}function answer(n){if(answered)return;answered=true;let q=qz[i],o=q.options[n],ok=(q.correctValues||[]).includes(o.value);if(ok)score++;feedback.innerHTML=(ok?'✅ Benar! ':'❌ Belum tepat. ')+(o.feedback||'')+'<br><button onclick="i++;render()">'+(i===qz.length-1?'Lihat hasil':'Soal berikutnya')+'</button>'}render();</script></body></html>"""
}
